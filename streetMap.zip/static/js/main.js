const adds = [
	"天津市蓟州区水库南岸中山北头村山野度假村",
	"北京市东城区王府井大街",
	"河北省唐山市路南区学院南路与南湖大道交叉口东500米",
	"河北省秦皇岛市昌黎县Y121(秦西线)",
	"河北省秦皇岛市山海关区龙海大道1号",
	"河北省承德市滦平县碧霞山风景区(滦阳路西100米)",
	"天津市武清区翠通路与雍和道交口",
	"河北省廊坊市安次区西昌路",
];	

var res = [];
var viewModel = {};
viewModel.addressList = ko.observableArray(adds); /* 用 adds 数组初始化*/
viewModel.clickItem = function(e) {
    myGeo.getPoint(e, function(point){
		if (point) {
			console.log(point.lng)
			var overL = map.getOverlays();
			for(let x = 0;x<overL.length;x++){
				if(overL[x].point && overL[x].point.lng == point.lng && overL[x].point.lat == point.lat){
					map.removeOverlay(overL[x]);   //为什么这个无法取消我的标记点？
				}
			}
			var marker = new BMap.Marker(point);
			map.addOverlay(marker);
			marker.setAnimation(BMAP_ANIMATION_BOUNCE); //跳动的动画
			weatherApi(marker)
		}
	});
}
viewModel.items = ko.observableArray();
viewModel.itemToAdd = ko.observable("");
viewModel.searchAddress = function () {
	res = [];
    if (viewModel.itemToAdd() != "") {
    	for(var i = 0;i< adds.length;i++){
    		if(adds[i].indexOf(viewModel.itemToAdd()) !== -1){
    			res.push(adds[i])
    		}
    	}
    	remove_overlay();
    	viewModel.items.push(viewModel.itemToAdd());	
    	bdGEO(res);
        viewModel.addressList(res); /* 更新左侧地点列表 */
    	bdGEO(res);
    } else {
	 	bdGEO(adds);
     	viewModel.addressList(adds); /* 更新左侧地点列表 */
    }
}

ko.applyBindings(viewModel);

/***********************************************百度地图API功能**********************************************************/
const map = new BMap.Map("map");
const top_right_navigation = new BMap.NavigationControl({anchor: BMAP_ANCHOR_TOP_RIGHT, type: BMAP_NAVIGATION_CONTROL_SMALL});
// 创建地址解析器实例
const myGeo = new BMap.Geocoder();
function bdGEO(adds){
	// 将地址解析结果显示在地图上,并调整地图视野
	myGeo.getPoint(adds[0], function(point){
		if (point) {
			map.centerAndZoom(point, 8);
			map.enableScrollWheelZoom(true);
			map.addControl(top_right_navigation);   
		}
		for(var index = 0;index<adds.length;index++){
			var add = adds[index];
			geocodeSearch(index,add);
		}
	});
}
function geocodeSearch(index,add){
	myGeo.getPoint(add, function(point){
		if (point) {
			// document.getElementById("resesult").innerHTML +=   add +"</br>";
			var address = new BMap.Point(point.lng, point.lat);
			addMarker(address,new BMap.Label(add,{offset:new BMap.Size(20,-10)}));
		}
	});
}
// 编写自定义函数,创建标注
function addMarker(point,label){
	var marker = new BMap.Marker(point);
	marker.addEventListener("click",attribute);  //添加点的点击事件
	map.addOverlay(marker);
	// marker.setLabel(label);
}
const opts = {
	width : 250,     // 信息窗口宽度
	height: 80,     // 信息窗口高度
	title : "天气信息" , // 信息窗口标题
	enableMessage:true//设置允许信息窗发送短息
};

var content = "获取信息失败！";
var jsonpCallback = function(data) {
	// 信息窗口添加天气数据
	content = data.results[0].now.text+"/"+data.results[0].now.temperature+"℃";
}
function attribute(e){
	var p = e.target;
	weatherApi(p);
}

function weatherApi(p){
	p.setAnimation(BMAP_ANIMATION_BOUNCE); //点击地图标记触发弹跳动画								
	var point = new BMap.Point(p.getPosition().lng, p.getPosition().lat);
	/* 2000 个毫秒之后取消动画 */
	setTimeout(function(){
        p.setAnimation(null);
    }, 2000); 

	var UID = "填写自己的心知天气用户UID"; 
	var KEY = "填写自己的心知天气用户KEY";
	var API = "http://api.seniverse.com/v3/weather/now.json"; // 获取天气实况
	var LOCATION = p.getPosition().lat+":"+p.getPosition().lng; 
	var ts = Math.floor((new Date()).getTime() / 1000);
	var str = "ts=" + ts + "&uid=" + UID;
	var sig = CryptoJS.HmacSHA1(str, KEY).toString(CryptoJS.enc.Base64);
	sig = encodeURIComponent(sig);
	str = str + "&sig=" + sig;
	var url = API + "?location=" + LOCATION + "&" + str;

	$.ajax({
	url: url,
	dataType: 'jsonp'  /* 以 jsonp 的方式亲求 */
	}).done(function(res){
	jsonpCallback(res)
	var infoWindow = new BMap.InfoWindow(content,opts);  // 创建信息窗口对象
	map.openInfoWindow(infoWindow,point); //开启信息窗口
	}).fail(function(error){
	  alert("天气信息API加载失败！")
	})
}
//清除覆盖物
function remove_overlay(){
	map.clearOverlays();         
}
// 自动解析地址并打点
window.onload = bdGEO(adds);